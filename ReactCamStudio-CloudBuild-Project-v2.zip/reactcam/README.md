# ReactCam Studio — Android source project

This is a source-code prototype and cloud-build-ready project, **not a finished or tested APK**. The included GitHub Actions workflow can compile a debug APK in a GitHub repository that has Actions enabled and upload the APK as a workflow artifact.

## Current prototype functionality
- Native Android project using Kotlin, Media3, and CameraX.
- Pick and play a video stored on the device.
- Request camera and microphone permissions and show a front-camera preview.
- Basic facecam sizing, draggable floating preview, and preview layout controls.
- Separate source-playback pause/resume controls and a Pause Everything control.
- Basic border on/off and color controls.

## Important limitations
- Combined source-video + facecam + microphone recording and export are not implemented.
- Source-only pause currently pauses playback while leaving the camera preview active; camera recording does not continue because recording is not implemented.
- Split divider dragging and adjustable border thickness are not implemented.
- YouTube playback and a full editor are not implemented.
- This source has not been compiled or tested on a device in this environment. Do not treat it as a release-ready app.

## Cloud build workflow
The workflow is at `.github/workflows/android-build.yml`. After this project is placed in a GitHub repository, the workflow builds `:app:assembleDebug` and uploads `app-debug.apk` as an artifact. This environment cannot create a new GitHub repository or run that remote workflow, and it has no Android SDK/Gradle or outbound network access, so it cannot produce or verify the APK here.
