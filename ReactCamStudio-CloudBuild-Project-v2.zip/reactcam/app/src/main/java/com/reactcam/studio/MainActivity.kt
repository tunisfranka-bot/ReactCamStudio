package com.reactcam.studio

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import android.app.Activity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var stage: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var cameraView: PreviewView
    private lateinit var player: ExoPlayer
    private lateinit var status: TextView
    private var pausedAll = false
    private var sourcePausedOnly = false
    private var cameraReady = false
    private var cameraWidth = 34
    private var borderEnabled = true
    private var borderColor = Color.WHITE
    private var borderSize = 4
    private var layoutName = "Floating Facecam"

    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.playWhenReady = true
            status.text = "Video loaded • ${layoutName}"
        }
    }
    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        else Toast.makeText(this, "Camera permission is needed for facecam.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionRequest.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(17,17,17)); setPadding(12, 12, 12, 12) }
        val title = TextView(this).apply { text = "ReactCam Studio"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL; setPadding(4, 8, 4, 12) }
        root.addView(title)
        stage = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply { player = this@MainActivity.player; useController = true; setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING) }
        stage.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        cameraView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER; setBackgroundColor(Color.DKGRAY) }
        val camLp = FrameLayout.LayoutParams(dp(cameraWidth), dp(150), Gravity.BOTTOM or Gravity.END).apply { setMargins(0,0,dp(8),dp(8)) }
        cameraView.setBackgroundColor(Color.DKGRAY)
        stage.addView(cameraView, camLp)
        cameraView.setOnTouchListener { view, event ->
            if (layoutName != "Floating Facecam") return@setOnTouchListener false
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> true
                android.view.MotionEvent.ACTION_MOVE -> {
                    view.x = (view.x + event.x - (view.width / 2f)).coerceIn(0f, (stage.width - view.width).coerceAtLeast(0).toFloat())
                    view.y = (view.y + event.y - (view.height / 2f)).coerceIn(0f, (stage.height - view.height).coerceAtLeast(0).toFloat())
                    true
                }
                else -> true
            }
        }
        root.addView(stage, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this).apply { text = "Choose a video to begin. Camera preview is separate from recording."; textSize = 12f; setTextColor(Color.LTGRAY); setPadding(4,8,4,8) }
        root.addView(status)
        row("Choose Video", "Pause Everything", "Resume") { which -> when(which) {
            "Choose Video" -> videoPicker.launch(arrayOf("video/*"))
            "Pause Everything" -> { pausedAll = true; player.pause(); status.text = "Playback paused. Camera preview stays on. Layout/settings can be changed." }
            "Resume" -> { pausedAll = false; sourcePausedOnly = false; player.play(); status.text = "Source playback resumed • ${layoutName}" }
        } }
        row("Pause Source Only", "Resume Source") { which -> when (which) {
            "Pause Source Only" -> { sourcePausedOnly = true; player.pause(); status.text = "Source video paused; front-camera preview remains active. Recording is not implemented yet." }
            "Resume Source" -> { sourcePausedOnly = false; player.play(); status.text = "Source video resumed • ${layoutName}" }
        } }
        row("Floating Facecam", "Equal Split", "Top and Bottom", "Side-by-Side") { layout -> applyLayout(layout) }
        val borderRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        borderRow.addView(Button(this).apply { text = "Border On/Off"; setOnClickListener { borderEnabled = !borderEnabled; updateBorder(); text = if (borderEnabled) "Border: ON" else "Border: OFF" } }, LinearLayout.LayoutParams(0, dp(48), 1f))
        borderRow.addView(Button(this).apply { text = "Border Color"; setOnClickListener { borderColor = when(borderColor) { Color.WHITE -> Color.YELLOW; Color.YELLOW -> Color.RED; else -> Color.WHITE }; updateBorder() } }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(borderRow)
        val sizeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sizeRow.addView(TextView(this).apply { text = "Facecam size"; setTextColor(Color.WHITE) })
        sizeRow.addView(SeekBar(this).apply { max = 65; progress = cameraWidth - 20; setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { cameraWidth = progress + 20; resizeCamera() }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }) }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(sizeRow)
        root.addView(TextView(this).apply { text = "Prototype: preview and playback only. Recording/export is not implemented yet."; setTextColor(Color.YELLOW); textSize = 12f; setPadding(4,8,4,8) })
        setContentView(root)
    }

    private fun row(vararg labels: String, action: (String) -> Unit) {
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        labels.forEach { label -> line.addView(Button(this).apply { text = label; textSize = 10f; setOnClickListener { action(label) } }, LinearLayout.LayoutParams(0, dp(48), 1f)) }
        root.addView(line)
    }

    private fun applyLayout(name: String) {
        if (!pausedAll) {
            status.text = "Tap Pause Everything before changing layout."
            return
        }
        layoutName = name
        val halfW = (stage.width / 2).coerceAtLeast(dp(80))
        val halfH = (stage.height / 2).coerceAtLeast(dp(80))
        when (name) {
            "Equal Split", "Side-by-Side" -> {
                playerView.layoutParams = FrameLayout.LayoutParams(halfW, -1, Gravity.START)
                cameraView.layoutParams = FrameLayout.LayoutParams(halfW, -1, Gravity.END)
                cameraView.translationX = 0f; cameraView.translationY = 0f
            }
            "Top and Bottom" -> {
                playerView.layoutParams = FrameLayout.LayoutParams(-1, halfH, Gravity.TOP)
                cameraView.layoutParams = FrameLayout.LayoutParams(-1, halfH, Gravity.BOTTOM)
                cameraView.translationX = 0f; cameraView.translationY = 0f
            }
            else -> {
                playerView.layoutParams = FrameLayout.LayoutParams(-1, -1)
                resizeCamera()
            }
        }
        status.text = "Preview layout: $name. Video composition/export is still under development."
    }

    private fun resizeCamera() {
        if (!::cameraView.isInitialized || !::stage.isInitialized) return
        if (layoutName != "Floating Facecam") return
        val w = (stage.width * cameraWidth / 100f).toInt().coerceAtLeast(dp(80))
        val h = (w * 0.65f).toInt().coerceAtLeast(dp(70))
        cameraView.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.BOTTOM or Gravity.END).apply { setMargins(0,0,dp(8),dp(8)) }
        updateBorder()
    }

    private fun updateBorder() {
        cameraView.background = if (borderEnabled) android.graphics.drawable.GradientDrawable().apply { setColor(Color.DKGRAY); setStroke(dp(borderSize), borderColor) } else android.graphics.drawable.ColorDrawable(Color.DKGRAY)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(cameraView.surfaceProvider) }
                provider.unbindAll(); provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview)
                cameraReady = true; status.text = "Front-camera preview ready. Choose a video to begin."
            } catch (e: Exception) { status.text = "Camera could not start: ${e.message}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    override fun onDestroy() { super.onDestroy(); player.release() }
}
